package com.yash.oppsconcept.task3;

public class Twosides 
{

	
	public void area(int side1,int side2)
	{	
	System.out.println("Area of squer="+side1*side2);
	}

}
