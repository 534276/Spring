package com.yash.oppsconcept.task6;

public class Test
{
	public static void main(String[] args) 
	{
Parent p=new Child();
p.comprestring("abc", "abc");
	}
}
